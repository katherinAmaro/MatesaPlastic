﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Proyecto.Modelo;
using System.Windows.Forms;

namespace MPlastic.View
{
    public partial class AltaTurno : System.Web.UI.Page
    {
        
        Empleado obj = new Empleado();
        Turno obj2 = new Turno();
        protected void Page_Load(object sender, EventArgs e)
        {
            int r = obj.carga_idEmpleado(DropDownList1);
            if (r == -1)

                MessageBox.Show("error al conectarse a la base de datos");
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
          
            obj2.idEmpleado = Convert.ToInt32(DropDownList1.SelectedItem.Text);
            obj2.turno = DropDownList3.SelectedItem.Text;
            obj2.HoraEntrada = TextBox1.Text;
            obj2.HoraSalida = TextBox2.Text;
            int r = obj2.altaTurno();
            if (r == 1)
                ClientScript.RegisterStartupScript(GetType(), "mostrar", "registroTurno();", true);
            else if (r == 0)
                ClientScript.RegisterStartupScript(GetType(), "mostrar", "erRegistroTurno();", true);
            else
               ClientScript.RegisterStartupScript(GetType(), "mostrar", "erRegistroTurno();", true);
        }
    }
}