﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Proyecto.Modelo;
using System.Windows.Forms;

namespace MPlastic.View
{
    public partial class ModificarProducto : System.Web.UI.Page
    {
        Producto obj = new Producto();
        protected void Page_Load(object sender, EventArgs e)
        {
            int r = obj.cargar_productos(DropDownList2);
            if (r == -1)

                MessageBox.Show("error al conectarse a la base de datos");
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            
            TextBox7.Text = obj.regresa_nombre(Convert.ToInt32(DropDownList2.Text));
            TextBox6.Text = obj.regresa_descripcion(Convert.ToInt32(DropDownList2.Text));
            TextBox1.Text = obj.regresa_status(Convert.ToInt32(DropDownList2.Text));
        }

        protected void Button1_Click1(object sender, EventArgs e)
        {
            obj.idProducto = Convert.ToInt32(DropDownList2.Text);
            obj.Descripcion = TextBox6.Text;
            obj.Nombre = TextBox7.Text;
            obj.Status = TextBox1.Text;



            int r = obj.actualiza_producto();
            if (r == 1)
                ClientScript.RegisterStartupScript(GetType(), "mostrar", "modificacionProducto();", true);
            else if (r == 0)
                ClientScript.RegisterStartupScript(GetType(), "mostrar", "ermodificacionProducto();", true);
            else
                ClientScript.RegisterStartupScript(GetType(), "mostrar", "ermodificacionProducto();", true);
        }
    }
}