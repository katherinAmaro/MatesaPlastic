﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Proyecto.Modelo;
using System.Windows.Forms;

namespace MPlastic.View
{
    public partial class BajaProducto : System.Web.UI.Page
    {
        Producto obj_producto = new Producto();
        protected void Page_Load(object sender, EventArgs e)
        {
            int r = obj_producto.cargar_productos(DropDownList1);
            if (r == -1)

                MessageBox.Show("error al conectarse a la base de datos");

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            int r = obj_producto.baja(Convert.ToInt32(DropDownList1.Text));
            if (r == 0)
                ClientScript.RegisterStartupScript(GetType(), "mostrar", "bajaProducto();", true);
            else if (r == 1)
                ClientScript.RegisterStartupScript(GetType(), "mostrar", "erbajaProducto();", true);
            else
                ClientScript.RegisterStartupScript(GetType(), "mostrar", "erbajaProducto();", true);
        }
    }
}