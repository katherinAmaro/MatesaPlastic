﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Proyecto.Modelo;

namespace MPlastic.View
{
    public partial class AltaObrero : System.Web.UI.Page
    {
        Persona obj = new Persona();
        Empleado obj2 = new Empleado();
        protected void Page_Load(object sender, EventArgs e)
        {
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            //obj.idPersona = Convert.ToInt32(TextBox1.Text);
            obj.Nombre = TextBox6.Text;
            obj.ApellidoPaterno = TextBox2.Text;
            obj.ApellidoMaterno = TextBox3.Text;
            obj.RFC = TextBox4.Text;
            obj.FNacimiento = TextBox5.Text;
            //obj2.idEmpleado = Convert.ToInt32(TextBox7.Text);
            //obj2.idPersona = Convert.ToInt32(TextBox1.Text);

            int r = obj.altaPersona();
            if (r == 1)
                ClientScript.RegisterStartupScript(GetType(), "mostrar", "registroEmpleado();", true);
            else if (r == 0)
                ClientScript.RegisterStartupScript(GetType(), "mostrar", "erRegistroEmpleado();", true);
            else
                ClientScript.RegisterStartupScript(GetType(), "mostrar", "erRegistroEmpleado();", true);
             }

        protected void ImageBtn_Click(object sender, ImageClickEventArgs e)
        {

        }

        protected void Calendar1_SelectionChanged(object sender, EventArgs e)
        {
      
        }
    }
}