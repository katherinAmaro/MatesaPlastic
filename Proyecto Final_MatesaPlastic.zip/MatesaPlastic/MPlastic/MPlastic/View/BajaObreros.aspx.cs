﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Proyecto.Modelo;
using System.Windows.Forms;

namespace MPlastic.View
{
    public partial class BajaObreros : System.Web.UI.Page
    {
        Empleado obj = new Empleado();
        protected void Page_Load(object sender, EventArgs e)
        {
            int r = obj.carga_idEmpleado(DropDownList1);
            if (r == -1)

                MessageBox.Show("error al conectarse a la base de datos");

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            int r = obj.bajaEmpleado(Convert.ToInt32(DropDownList1.SelectedItem.Text));
            if (r == 0)
                ClientScript.RegisterStartupScript(GetType(), "mostrar", "bajaObrero();", true);
            else if (r == 1)
                ClientScript.RegisterStartupScript(GetType(), "mostrar", "erbajaObrero()", true);
            else
                ClientScript.RegisterStartupScript(GetType(), "mostrar", "erbajaObrero();", true);


        }
    }
}