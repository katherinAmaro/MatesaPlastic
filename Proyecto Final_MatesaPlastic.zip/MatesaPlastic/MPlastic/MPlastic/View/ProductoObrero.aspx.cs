﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Proyecto.Modelo;
namespace MPlastic.View
{
    public partial class ProductoObrero : System.Web.UI.Page
    {
        ProductoTer obj = new ProductoTer();
        Empleado objem = new Empleado();
        Producto objp = new Producto();

        protected void Page_Load(object sender, EventArgs e)
        {
            objem.carga_idEmpleado(DropDownList1);
            objp.muestra_idProductos(DropDownList2);
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            obj.idEmpleado = Convert.ToInt32(DropDownList1.SelectedItem.Text);
            obj.idProducto = Convert.ToInt32(DropDownList2.SelectedItem.Text);
            obj.Cantidad = Convert.ToInt32(TextBox1.Text);
            obj.Fecha = TextBox2.Text;
            obj.pzasBEstado = TextBox3.Text;
            obj.pzasDefec = TextBox4.Text;
            obj.Stock = Convert.ToInt32( TextBox5.Text);
            
           int r= obj.altaProductoTer();
            
            if (r == 1)
                ClientScript.RegisterStartupScript(GetType(), "mostrar", "registroProductoOb();", true);
            else if (r == 0)
                ClientScript.RegisterStartupScript(GetType(), "mostrar", "erRegistroProductoOb();", true);
            else
                ClientScript.RegisterStartupScript(GetType(), "mostrar", "erRegistroProductoOb();", true);
             
        }
    }
}