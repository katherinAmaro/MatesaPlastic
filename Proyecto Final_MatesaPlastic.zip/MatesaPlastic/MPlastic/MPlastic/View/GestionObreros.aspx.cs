﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Proyecto.Modelo;
namespace MPlastic.View
{
    public partial class GestionObreros : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Calendar1.Visible = false;
            
        }

        protected void Btnbusca_Click(object sender, EventArgs e)
        {
            ProductoTer pe = new ProductoTer();
            DateTime fi = DateTime.Parse(TxtInicial.Text);
            DateTime ff = DateTime.Parse(TxtFinal.Text);
            pe.ConsultaProdcto(GridView1, fi, ff);
        }

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            if (Calendar1.Visible)
            {
                Calendar1.Visible = false;
            }
            else
            {
                Calendar1.Visible = true;
            }
        }

        protected void Calendar1_SelectionChanged(object sender, EventArgs e)
        {
            TxtInicial.Text = Calendar1.SelectedDate.ToShortDateString();
            Calendar1.Visible = false;
      
        }
    }
}