﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Proyecto.Modelo;
namespace MPlastic.View
{
    public partial class GestionProducto : System.Web.UI.Page
    {
        Producto objprod = new Producto();
        ProductoTer objpr = new ProductoTer();
        protected void Page_Load(object sender, EventArgs e)
        {
            objprod.cargar_nombre_productos(DropDownList1);
        }
    }
}