﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Proyecto.Modelo;
using System.Windows.Forms;

namespace MPlastic.View
{
    public partial class AltaEmpleados : System.Web.UI.Page
    {
        Persona obj = new Persona();
        Empleado obj2 = new Empleado();
        protected void Page_Load(object sender, EventArgs e)
        {
            int r = obj.carga_idPersona(DropDownList1);
            if (r == -1)

                MessageBox.Show("error al conectarse a la base de datos");

        }

        protected void Button1_Click(object sender, EventArgs e)
        {

            if (DropDownList1.SelectedItem.Selected == null || TextBox2.Text == "" || TextBox3.Text == "")
            {
                ClientScript.RegisterStartupScript(GetType(), "mostrar", "al();", true);
            }

            else
            {
                obj2.idPersona = Convert.ToInt32(DropDownList1.SelectedItem.Text);
                obj2.Usuario = TextBox2.Text;
                obj2.Contraseña = TextBox3.Text;

                int r = obj2.altaEmpleado();
                if (r == 1)
                    ClientScript.RegisterStartupScript(GetType(), "mostrar", "registroEmpleado2();", true);
                else if (r == 0)
                    ClientScript.RegisterStartupScript(GetType(), "mostrar", "erRegistroEmpleado2();", true);
                else
                    ClientScript.RegisterStartupScript(GetType(), "mostrar", "erRegistroEmpleado2();", true);
            }
        }
    }
}