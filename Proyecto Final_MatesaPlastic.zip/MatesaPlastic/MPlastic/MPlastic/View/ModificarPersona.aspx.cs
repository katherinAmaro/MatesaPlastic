﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Proyecto.Modelo;
using System.Windows.Forms;


namespace MPlastic.View
{
    public partial class ModificarPersona : System.Web.UI.Page
    {
        Persona obj = new Persona();
        protected void Page_Load(object sender, EventArgs e)
        {
            int r = obj.cargar_persona(DropDownList1);
            if (r == -1)

                MessageBox.Show("error al conectarse a la base de datos");
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            TextBox1.Text = obj.regresa_nombre(Convert.ToInt32(DropDownList1.Text));
            TextBox2.Text = obj.regresa_apePa(Convert.ToInt32(DropDownList1.Text));
            TextBox3.Text = obj.regresa_apeMa(Convert.ToInt32(DropDownList1.Text));
            TextBox4.Text = obj.regresa_rfc(Convert.ToInt32(DropDownList1.Text));
            TextBox5.Text = obj.regresa_fnac(Convert.ToInt32(DropDownList1.Text));
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            obj.idPersona = Convert.ToInt32(DropDownList1.Text);
            obj.Nombre = TextBox1.Text;
            obj.ApellidoPaterno = TextBox2.Text;
            obj.ApellidoMaterno = TextBox3.Text;
            obj.RFC = TextBox4.Text;
            obj.FNacimiento = TextBox5.Text;



            int r = obj.actualiza_persona();
            if (r == 1)
                ClientScript.RegisterStartupScript(GetType(), "mostrar", "modificacionObrero();", true);
            else if (r == 0)
                ClientScript.RegisterStartupScript(GetType(), "mostrar", "ermodificacionObrero();", true);
            else
                ClientScript.RegisterStartupScript(GetType(), "mostrar", "ermodificacionObrero();", true);
        }
    }
}