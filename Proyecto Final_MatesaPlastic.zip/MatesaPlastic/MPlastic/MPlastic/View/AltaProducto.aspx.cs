﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Proyecto.Modelo;

namespace MPlastic.View
{
    public partial class AltaProducto : System.Web.UI.Page
    {
        Producto obj = new Producto();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            //obj.idProducto = Convert.ToInt32(TextBox1.Text);
            obj.Descripcion = TextBox2.Text;
            obj.Nombre = TextBox3.Text;
            int r = obj.altaProducto();
            if (r == 1)
                ClientScript.RegisterStartupScript(GetType(), "mostrar", "registroProducto();", true);
            else if (r == 0)
                ClientScript.RegisterStartupScript(GetType(), "mostrar", "erRegistroProducto();", true);
            else
                ClientScript.RegisterStartupScript(GetType(), "mostrar", "erRegistroProducto();", true);
            

        }
    }
}