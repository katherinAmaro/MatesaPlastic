﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Proyecto.Modelo;
using System.Windows.Forms;

namespace MPlastic.View
{
    public partial class ModificarEmpleado : System.Web.UI.Page
    {
        Empleado obj = new Empleado();
        protected void Page_Load(object sender, EventArgs e)
        {
            int r = obj.carga_idEmpleado(DropDownList2);
            if (r == -1)

                MessageBox.Show("error al conectarse a la base de datos");

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            TextBox1.Text = obj.regresa_usuario(Convert.ToInt32(DropDownList2.Text));
            TextBox2.Text = obj.regresa_contraseña(Convert.ToInt32(DropDownList2.Text));
            TextBox3.Text = obj.regresa_status(Convert.ToInt32(DropDownList2.Text));
        }

        protected void Button2_Click1(object sender, EventArgs e)
        {
            obj.idEmpleado = Convert.ToInt32(DropDownList2.Text);
            obj.Usuario = TextBox1.Text;
            obj.Contraseña = TextBox2.Text;
            obj.Status = TextBox3.Text;

            int r = obj.actualiza_empleado();
            if (r == 1)
                ClientScript.RegisterStartupScript(GetType(), "mostrar", "modificacionEmpleado();", true);
            else if (r == 0)
                ClientScript.RegisterStartupScript(GetType(), "mostrar", "ermodificacionEmpleado();", true);
            else
                ClientScript.RegisterStartupScript(GetType(), "mostrar", "ermodificacionEmpleado();", true);
        }
    }
}